# # from django.shortcuts import render, HttpResponse
# # from .models import vehicle, booking, User_tbl, payment


# # # Create your views here.
# # def index(request):
# #     User = vehicle.get_inative()
# #     return render(request, 'User.html', {'User': User})


# # def bookings(request, pk):
# #     if request.method == "POST":
# #         reg = request.POST.get('reg')
# #         amount = request.POST.get('amount')
# #         time = request.POST.get('time')
# #         paymen = request.POST.get('payment')
# #         if paymen == 'COD':
# #             pay = 1
# #         else:
# #             pay = 0
# #         id = vehicle.objects.get(reg_no=reg)
# #         phone = request.session['user']
# #         uid= User_tbl.objects.get(phonenumber=phone)

# #         saverecords = booking()
# #         bid = booking.objects.filter(Userid=uid).last().Bookingid

# #         if bid:
# #             bid=bid+1
# #         else:
# #             bid=1
# #         saverecords.BookingId=bid
# #         saverecords.VehicleId = id
# #         saverecords.Userid = uid
# #         saverecords.Time = time
# #         saverecords.Amount = amount
# #         saverecords.PaymentStatus = pay
# #         saverecords.complete = 0
# #         saverecords.accept =0
# #         saverecords.save()

# #         bid = booking.objects.get(Bookingid=bid)
# #         saverecords= payment()
# #         saverecords.BookingId = bid
# #         saverecords.Amount = amount
# #         saverecords.Mode = paymen
# #         saverecords.save()
# #         return HttpResponse("Booking Completed")
# #     veh = vehicle.objects.filter(reg_no=pk)
# #     return render(request, 'Booking.html', {'veh': veh})


# # def previous(request):
# #     phone = request.session['user']
# #     uid = User_tbl.objects.filter(phonenumber=phone).last().Userid
# #     book = booking.objects.filter(Userid=uid)

# #     vehi=book.last().VehicleId.Vehicleid
# #     vehic = vehicle.objects.filter(Vehicleid=vehi)

# #     return render(request, 'previous.html',{'veh':book,'vehi':vehic})

# # def ongoing(request):
# #     phone = request.session['user']
# #     uid = User_tbl.objects.filter(phonenumber=phone).last().Userid
# #     if request.method == "POST":
# #         booked = request.POST.get('submit')
# #         saverecord = booking.objects.filter(Bookingid=booked).last()
# #         saverecord.complete = 1
# #         saverecord.save()

# #     book = booking.objects.filter(Userid=uid,complete=0)
# #     if book is not None:
# #         vehi=book.last().VehicleId.Vehicleid
# #         vehic = vehicle.objects.filter(Vehicleid=vehi)
# #         return render(request, 'ongoing.html',{'veh':book,'vehi':vehic})
# #     return render(request, 'ongoing.html')



# from django.shortcuts import render, HttpResponse
# from .models import vehicle, booking, User_tbl, payment

# # Home view to display available taxis
# def index(request):
#     User = vehicle.get_inative()  # Assuming this fetches inactive vehicles
#     return render(request, 'User.html', {'User': User})

# # Booking view with POST handling for booking confirmation
# from django.shortcuts import render, get_object_or_404
# from django.http import HttpResponse
# from .models import vehicle, User_tbl, booking, payment

# def bookings(request, pk):
#     veh = get_object_or_404(vehicle, reg_no=pk)  # Fetch the vehicle based on reg_no

#     if request.method == "POST":
#         reg = request.POST.get('reg')
#         amount = request.POST.get('amount')
#         time = request.POST.get('time')
#         payment_method = request.POST.get('payment')

#         # Get the user phone number from session
#         phone = request.session.get('user')
#         uid = get_object_or_404(User_tbl, phonenumber=phone)  # Fetch user based on phone number
        
#         # Create a new booking record
#         saverecords = booking()
#         last_booking = booking.objects.filter(Userid=uid).order_by('Bookingid').last()

#         if last_booking:
#             saverecords.BookingId = last_booking.Bookingid + 1
#         else:
#             saverecords.BookingId = 1  # If no bookings exist, start from 1

#         saverecords.VehicleId = veh
#         saverecords.Userid = uid
#         saverecords.Time = time
#         saverecords.Amount = amount
#         saverecords.PaymentStatus = 1 if payment_method == 'COD' else 0
#         saverecords.complete = 0
#         saverecords.accept = 0
#         saverecords.save()

#         # Create the payment record
#         saverecords_payment = payment()
#         saverecords_payment.BookingId = saverecords  # Set the booking object directly
#         saverecords_payment.Amount = amount
#         saverecords_payment.Mode = payment_method
#         saverecords_payment.save()

#         return HttpResponse("Booking Completed")
    
#     return render(request, 'Booking.html', {'veh': [veh]})  # Pass vehicle as a list
# # View for displaying previous bookings with error handling for empty records
# def previous(request):
#     phone = request.session.get('user')
#     if not phone:
#         return HttpResponse("User not logged in", status=403)

#     uid = User_tbl.objects.filter(phonenumber=phone).last().Userid
#     book = booking.objects.filter(Userid=uid)

#     if not book.exists():
#         return HttpResponse("No previous bookings found.", status=404)

#     vehi = book.last().VehicleId.Vehicleid
#     vehic = vehicle.objects.filter(Vehicleid=vehi)

#     return render(request, 'previous.html', {'veh': book, 'vehi': vehic})

# # View for ongoing bookings with POST handling to complete a booking
# # 
# def ongoing(request):
#     if request.method == "POST":
#         # Get user phone number from session
#         phone = request.session.get('user')
        
#         if not phone:
#             return HttpResponse("User not logged in", status=403)  # Forbidden if user is not logged in
        
#         uid = get_object_or_404(User_tbl, phonenumber=phone)  # Fetch user based on phone number
        
#         # Fetch last booking associated with the user
#         last_booking = booking.objects.filter(Userid=uid).order_by('Bookingid').last()
        
#         # Determine the next booking ID
#         if last_booking:
#             next_booking_id = last_booking.Bookingid + 1
#         else:
#             next_booking_id = 1  # Start from 1 if no previous bookings exist

#         # Ensure the next_booking_id is valid
#         if not isinstance(next_booking_id, int) or next_booking_id <= 0:
#             return HttpResponse("Invalid Booking ID", status=400)  # Bad request

#         # Now you can proceed to create a new booking record
#         new_booking = booking()
#         new_booking.BookingId = next_booking_id  # Set the next booking ID
#         new_booking.Userid = uid
#         # Set other fields as required
#         new_booking.save()

#         return HttpResponse("New booking created with ID: {}".format(new_booking.BookingId))
    
#     # Handle GET request if necessary
#     return render(request, 'your_template.html')  # Render your template

# def search(request):
#     query = request.GET.get('query', '')  # Get the search query from GET parameters
#     results = YourModel.objects.filter(field_name__icontains=query)  # Replace field_name with the field to search

#     return render(request, 'search_results.html', {'results': results})

# User/views.py
from django.shortcuts import render, HttpResponse, get_object_or_404
from Vehicle.models import Vehicle  # Ensure correct import of the Vehicle model
from .models import Booking, User_tbl, Payment

def index(request):
    inactive_vehicles = Vehicle.get_inactive()  # Fetch inactive vehicles
    active_vehicles = Vehicle.get_active()  # Fetch active vehicles

    return render(request, 'User.html', {
        'inactive_vehicles': inactive_vehicles,
        'active_vehicles': active_vehicles
    })

from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from .models import Vehicle, Booking, User_tbl, Payment

def bookings(request, reg_no):
    # Fetch the vehicle using the provided registration number
    veh = get_object_or_404(Vehicle, reg_no=reg_no)  # Adjust 'reg_no' to match your Vehicle model field

    if request.method == "POST":
        amount = request.POST.get('amount')
        time = request.POST.get('time')
        payment_method = request.POST.get('payment')

        # Get user phone number from session
        phone = request.session.get('user')
        users = User_tbl.objects.filter(phonenumber=phone)

        if users.exists():
            uid = users.first()  # Get the first user
        else:
            return HttpResponse("User not found", status=404)

        # Create a new booking record
        saverecords = Booking()  # Instantiate Booking
        last_booking = Booking.objects.filter(Userid=uid).order_by('Bookingid').last()

        if last_booking:
            saverecords.Bookingid = last_booking.Bookingid + 1
        else:
            saverecords.Bookingid = 1

        # Assign values to the booking record
        saverecords.VehicleId = veh
        saverecords.Userid = uid
        saverecords.Time = time
        saverecords.Amount = amount
        saverecords.PaymentStatus = 1 if payment_method == 'COD' else 0
        saverecords.complete = 0
        saverecords.accept = 0
        
        # Save the booking record
        saverecords.save()

        # Create the payment record
        saverecords_payment = Payment()
        saverecords_payment.BookingId = saverecords
        saverecords_payment.Amount = amount
        saverecords_payment.Mode = payment_method
        saverecords_payment.save()

        return HttpResponse("Booking Completed")

    # If the method is GET, render your booking page with vehicle info
    return render(request, 'booking.html', {'vehicle': veh})  # Pass the vehicle directly
# def bookings(request, reg_no):
#     # Fetch the vehicle using the provided registration number
#     veh = get_object_or_404(Vehicle, reg_no=reg_no)

#     if request.method == "POST":
#         amount = request.POST.get('amount')
#         time = request.POST.get('time')
#         payment_method = request.POST.get('payment')

#         # Get user phone number from session
#         phone = request.session.get('user')
#         users = User_tbl.objects.filter(phonenumber=phone)

#         if users.exists():
#             uid = users.first()  # Get the first user
#         else:
#             return HttpResponse("User not found", status=404)

#         # Create a new booking record
#         saverecords = Booking()  # Instantiate Booking
#         last_booking = Booking.objects.filter(Userid=uid).order_by('Bookingid').last()

#         if last_booking:
#             saverecords.Bookingid = last_booking.Bookingid + 1
#         else:
#             saverecords.Bookingid = 1

#         # Assign the Vehicle instance
#         saverecords.VehicleId = veh  # Correct assignment of Vehicle instance
#         saverecords.Userid = uid
#         saverecords.Time = time
#         saverecords.Amount = amount
        
#         # Set payment status based on the payment method
#         saverecords.PaymentStatus = 1 if payment_method == 'COD' else 0
#         saverecords.complete = 0
#         saverecords.accept = 0
        
#         # Save the booking record
#         saverecords.save()

#         # Redirect to a relevant view after saving
#         return redirect('some_view_name')  # Replace with your actual redirect view name

#     # If the method is GET, render your booking page with vehicle info
#     return render(request, 'booking.html', {'vehicle': veh})
def previous(request):
    phone = request.session.get('user')
    if not phone:
        return HttpResponse("User not logged in", status=403)

    uid = User_tbl.objects.filter(phonenumber=phone).last().Userid  # Get the user's ID
    bookings = Booking.objects.filter(Userid=uid)  # Use 'Userid' instead of 'user'

    if not bookings.exists():
        return HttpResponse("No previous bookings found.", status=404)

    # Fetch the last booking's vehicle
    last_booking = bookings.last()
    vehic = Vehicle.objects.filter(Vehicleid=last_booking.VehicleId.Vehicleid)

    return render(request, 'previous.html', {'veh': bookings, 'vehi': vehic})

def ongoing(request):
    phone = request.session.get('user')
    if not phone:
        return HttpResponse("User not logged in", status=403)

    uid = get_object_or_404(User_tbl, phonenumber=phone)

    if request.method == "POST":
        booked = request.POST.get('submit')
        print(f"Booked ID submitted: {booked}")  # Debug output

        # Validate 'booked' to ensure it is not empty
        if booked and booked.isdigit():
            saverecord = Booking.objects.filter(Bookingid=booked).last()
            if saverecord:
                saverecord.complete = 1
                saverecord.save()
                return HttpResponse("Booking marked as completed")
            else:
                return HttpResponse("Booking not found", status=404)
        else:
            return HttpResponse("Invalid Booking ID", status=400)

    bookings = Booking.objects.filter(Userid=uid, complete=0)
    vehicles = []

    if bookings.exists():
        for booking in bookings:
            vehicles.append(booking.VehicleId)

    return render(request, 'ongoing.html', {'veh': bookings, 'vehi': vehicles})

def search(request):
    if request.method == "POST":
        pickup = request.POST.get('pickup')
        drop = request.POST.get('drop')
        
        # Filter vehicles based on pickup and drop locations
        results = Vehicle.objects.filter(pickup__icontains=pickup, drop__icontains=drop)

        return render(request, 'search_results.html', {'results': results})
    
    pickup_locations = Vehicle.objects.values_list('pickup', flat=True).distinct()  # Unique pickup locations
    drop_locations = Vehicle.objects.values_list('drop', flat=True).distinct()  # Unique drop locations
    return render(request, 'search.html', {'pickup': pickup_locations, 'drop': drop_locations})





































# from django.shortcuts import render, HttpResponse, get_object_or_404
# from Vehicle.models import Vehicle  # Ensure correct import of the Vehicle model
# from .models import Booking, User_tbl, Payment

# def index(request):
#     inactive_vehicles = Vehicle.get_inactive()  # Fetch inactive vehicles
#     return render(request, 'User.html', {'User': inactive_vehicles})

# from django.shortcuts import render, get_object_or_404, redirect
# from django.http import HttpResponse
# from .models import Vehicle, Booking, User_tbl, Payment

# def bookings(request, reg_no):
#     # Fetch the vehicle using the provided registration number
#     veh = get_object_or_404(Vehicle, reg_no=reg_no)  # Adjust 'reg_no' to match your Vehicle model field

#     if request.method == "POST":
#         amount = request.POST.get('amount')
#         time = request.POST.get('time')
#         payment_method = request.POST.get('payment')

#         # Get user phone number from session
#         phone = request.session.get('user')
#         users = User_tbl.objects.filter(phonenumber=phone)

#         if users.exists():
#             uid = users.first()  # Get the first user
#         else:
#             return HttpResponse("User not found", status=404)

#         # Create a new booking record
#         saverecords = Booking()  # Instantiate Booking
#         last_booking = Booking.objects.filter(Userid=uid).order_by('Bookingid').last()

#         if last_booking:
#             saverecords.Bookingid = last_booking.Bookingid + 1
#         else:
#             saverecords.Bookingid = 1

#         # Assign values to the booking record
#         saverecords.VehicleId = veh
#         saverecords.Userid = uid
#         saverecords.Time = time
#         saverecords.Amount = amount
#         saverecords.PaymentStatus = 1 if payment_method == 'COD' else 0
#         saverecords.complete = 0
#         saverecords.accept = 0
        
#         # Save the booking record
#         saverecords.save()

#         # Create the payment record
#         saverecords_payment = Payment()
#         saverecords_payment.BookingId = saverecords
#         saverecords_payment.Amount = amount
#         saverecords_payment.Mode = payment_method
#         saverecords_payment.save()

#         return HttpResponse("Booking Completed")

#     # If the method is GET, render your booking page with vehicle info
#     return render(request, 'booking.html', {'vehicle': veh})  # Pass the vehicle directly
# # def bookings(request, reg_no):
# #     # Fetch the vehicle using the provided registration number
# #     veh = get_object_or_404(Vehicle, reg_no=reg_no)

# #     if request.method == "POST":
# #         amount = request.POST.get('amount')
# #         time = request.POST.get('time')
# #         payment_method = request.POST.get('payment')

# #         # Get user phone number from session
# #         phone = request.session.get('user')
# #         users = User_tbl.objects.filter(phonenumber=phone)

# #         if users.exists():
# #             uid = users.first()  # Get the first user
# #         else:
# #             return HttpResponse("User not found", status=404)

# #         # Create a new booking record
# #         saverecords = Booking()  # Instantiate Booking
# #         last_booking = Booking.objects.filter(Userid=uid).order_by('Bookingid').last()

# #         if last_booking:
# #             saverecords.Bookingid = last_booking.Bookingid + 1
# #         else:
# #             saverecords.Bookingid = 1

# #         # Assign the Vehicle instance
# #         saverecords.VehicleId = veh  # Correct assignment of Vehicle instance
# #         saverecords.Userid = uid
# #         saverecords.Time = time
# #         saverecords.Amount = amount
        
# #         # Set payment status based on the payment method
# #         saverecords.PaymentStatus = 1 if payment_method == 'COD' else 0
# #         saverecords.complete = 0
# #         saverecords.accept = 0
        
# #         # Save the booking record
# #         saverecords.save()

# #         # Redirect to a relevant view after saving
# #         return redirect('some_view_name')  # Replace with your actual redirect view name

# #     # If the method is GET, render your booking page with vehicle info
# #     return render(request, 'booking.html', {'vehicle': veh})
# def previous(request):
#     phone = request.session.get('user')
#     if not phone:
#         return HttpResponse("User not logged in", status=403)

#     uid = User_tbl.objects.filter(phonenumber=phone).last().Userid  # Get the user's ID
#     bookings = Booking.objects.filter(Userid=uid)  # Use 'Userid' instead of 'user'

#     if not bookings.exists():
#         return HttpResponse("No previous bookings found.", status=404)

#     # Fetch the last booking's vehicle
#     last_booking = bookings.last()
#     vehic = Vehicle.objects.filter(Vehicleid=last_booking.VehicleId.Vehicleid)

#     return render(request, 'previous.html', {'veh': bookings, 'vehi': vehic})

# def ongoing(request):
#     phone = request.session.get('user')
#     if not phone:
#         return HttpResponse("User not logged in", status=403)

#     uid = get_object_or_404(User_tbl, phonenumber=phone)

#     if request.method == "POST":
#         booked = request.POST.get('submit')
#         saverecord = Booking.objects.filter(Bookingid=booked).last()
#         if saverecord:
#             saverecord.complete = 1
#             saverecord.save()

#     bookings = Booking.objects.filter(user=uid, complete=0)  # Changed Userid to user
#     if bookings.exists():
#         vehic = Vehicle.objects.filter(Vehicleid=bookings.last().VehicleId.Vehicleid)
#         return render(request, 'ongoing.html', {'veh': bookings, 'vehi': vehic})

#     return render(request, 'ongoing.html')

# def search(request):
#     if request.method == "POST":
#         pickup = request.POST.get('pickup')
#         drop = request.POST.get('drop')
        
#         # Filter vehicles based on pickup and drop locations
#         results = Vehicle.objects.filter(pickup__icontains=pickup, drop__icontains=drop)

#         return render(request, 'search_results.html', {'results': results})
    
#     pickup_locations = Vehicle.objects.values_list('pickup', flat=True).distinct()  # Unique pickup locations
#     drop_locations = Vehicle.objects.values_list('drop', flat=True).distinct()  # Unique drop locations
#     return render(request, 'search.html', {'pickup': pickup_locations, 'drop': drop_locations})
