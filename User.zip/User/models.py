# # from django.db import models
# # from django.shortcuts import get_object_or_404


# # # Create your models here.


# # class User_tbl(models.Model):
# #     Userid = models.AutoField(auto_created=True, primary_key=True)
# #     email_id = models.CharField(max_length=100)
# #     name = models.CharField(max_length=100)
# #     address = models.CharField(max_length=100)
# #     phonenumber = models.CharField(max_length=15)
# #     password = models.CharField(max_length=100)
# #     role = models.CharField(max_length=100)


# # class vehicle(models.Model):
# #     Vehicleid = models.AutoField(auto_created=True, primary_key=True)
# #     User_id = models.ForeignKey("User_tbl",on_delete=models.CASCADE)
# #     reg_no = models.IntegerField()
# #     type = models.CharField(max_length=100)
# #     active = models.IntegerField()

# #     pickup = models.CharField(max_length=100)
# #     drop = models.CharField(max_length=100)
# #     amount = models.IntegerField()

# #     @staticmethod
# #     def get_inative():
# #         return vehicle.objects.filter(active=1)

# #     @staticmethod
# #     def get_location():
# #         return vehicle.objects.filter(active=0)


# # class booking(models.Model):
# #     Bookingid = models.AutoField(auto_created=True, primary_key=True)
# #     VehicleId = models.ForeignKey("vehicle",on_delete=models.CASCADE)
# #     Userid = models.ForeignKey("User_tbl",on_delete=models.CASCADE)
# #     Time = models.TimeField()
# #     PaymentStatus = models.IntegerField()
# #     Amount = models.IntegerField()
# #     accept = models.IntegerField()
# #     complete = models.IntegerField()

# #     @staticmethod
# #     def get_bookingid(id):
# #         return vehicle.objects.filter(active=0)

# #     @staticmethod
# #     def get_bookingdetail(id):
# # #         return vehicle.objects.filter(VehicleId=id)


# # # class payment(models.Model):
# # #     PaymentId = models.AutoField(auto_created=True, primary_key=True)
# # #     BookingId = models.ForeignKey("booking",on_delete=models.CASCADE)
# # #     Amount = models.IntegerField()
# # #     Mode = models.CharField(max_length=20)


# # # class review(models.Model):
# # #     ReviewId = models.AutoField(auto_created=True, primary_key=True)
# # #     UserId = models.ForeignKey("User_tbl",on_delete=models.CASCADE)
# # #     VehicleId = models.ForeignKey("vehicle",on_delete=models.CASCADE)
# # #     Review = models.CharField(max_length=1000)
# # #     Rating = models.IntegerField()


# from django.db import models
from django.db import models

# User model to store user information
class User_tbl(models.Model):
    Userid = models.AutoField(auto_created=True, primary_key=True)
    email_id = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    phonenumber = models.CharField(max_length=15)
    password = models.CharField(max_length=100)
    role = models.CharField(max_length=100)

    def __str__(self):
        return self.name


# Vehicle model to store vehicle details
class Vehicle(models.Model):
    Vehicleid = models.AutoField(auto_created=True, primary_key=True)
    User_id = models.ForeignKey(User_tbl, on_delete=models.CASCADE, related_name="user_vehicles")
    reg_no = models.CharField(max_length=15)  # Supports alphanumeric registration numbers
    type = models.CharField(max_length=100)
    active = models.IntegerField()
    pickup = models.CharField(max_length=100)
    drop = models.CharField(max_length=100)
    amount = models.IntegerField()

    @staticmethod
    def get_active():
        return Vehicle.objects.filter(active=1)

    @staticmethod
    def get_inactive():
        return Vehicle.objects.filter(active=0)

    def __str__(self):
        return f"{self.reg_no} - {self.type}"


# Booking model to store booking information
class Booking(models.Model):
    Bookingid = models.AutoField(auto_created=True, primary_key=True)
    VehicleId = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name="vehicle_bookings")
    Userid = models.ForeignKey(User_tbl, on_delete=models.CASCADE, related_name="user_bookings")
    Time = models.TimeField()
    PaymentStatus = models.IntegerField()
    Amount = models.IntegerField()
    accept = models.IntegerField()
    complete = models.IntegerField()

    @staticmethod
    def get_booking_by_id(id):
        return Booking.objects.filter(id=id).first()

    @staticmethod
    def get_booking_detail(vehicle_id):
        return Booking.objects.filter(VehicleId__Vehicleid=vehicle_id)

    def __str__(self):
        return f"Booking {self.Bookingid} for Vehicle {self.VehicleId}"
# Payment model to store payment details
class Payment(models.Model):
    PaymentId = models.AutoField(auto_created=True, primary_key=True)
    BookingId = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="booking_payments")
    Amount = models.IntegerField()
    Mode = models.CharField(max_length=20)

    def __str__(self):
        return f"Payment {self.PaymentId} - {self.Amount}"


# Review model to store user reviews
class review(models.Model):
    ReviewId = models.AutoField(auto_created=True, primary_key=True)
    UserId = models.ForeignKey(User_tbl, on_delete=models.CASCADE, related_name="user_reviews")
    VehicleId = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name="vehicle_reviews")
    Review = models.CharField(max_length=1000)
    Rating = models.IntegerField()

    def __str__(self):
        return f"Review {self.ReviewId} by {self.UserId}"

# from django.db import models

# class User_tbl(models.Model):
#     Userid = models.AutoField(auto_created=True, primary_key=True)
#     email_id = models.EmailField(max_length=100, unique=True)  # Email field for validation
#     name = models.CharField(max_length=100)
#     address = models.CharField(max_length=100)
#     phonenumber = models.CharField(max_length=15, unique=True)  # Unique for identification
#     password = models.CharField(max_length=100)
#     role = models.CharField(max_length=100)

#     def __str__(self):
#         return self.name  # Easy identification in admin


# class Vehicle(models.Model):
#     Vehicleid = models.AutoField(auto_created=True, primary_key=True)
#     User_id = models.ForeignKey(User_tbl, on_delete=models.CASCADE, related_name='vehicles')  # Proper relationship
#     reg_no = models.CharField(max_length=15, unique=True)  # Unique registration number
#     type = models.CharField(max_length=100)
#     active = models.BooleanField(default=False)
#     pickup = models.CharField(max_length=100)
#     drop = models.CharField(max_length=100)
#     amount = models.DecimalField(max_digits=10, decimal_places=2)

#     @staticmethod
#     def get_inactive():
#         return Vehicle.objects.filter(active=False)

#     @staticmethod
#     def get_location():
#         return Vehicle.objects.filter(active=True)

#     def __str__(self):
#         return f"{self.reg_no} - {self.type}"


# class Booking(models.Model):
#     Bookingid = models.AutoField(auto_created=True, primary_key=True)
#     VehicleId = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name='bookings')  # Fixed relationship
#     Userid = models.ForeignKey(User_tbl, on_delete=models.CASCADE, related_name='user_bookings')  # Fixed relationship
#     Time = models.TimeField()
#     PaymentStatus = models.BooleanField(default=False)
#     Amount = models.DecimalField(max_digits=10, decimal_places=2)
#     accept = models.BooleanField(default=False)
#     complete = models.BooleanField(default=False)

#     def __str__(self):
#         return f"Booking {self.Bookingid} for Vehicle {self.VehicleId}"


# class Payment(models.Model):
#     PaymentId = models.AutoField(auto_created=True, primary_key=True)
#     BookingId = models.ForeignKey(Booking, on_delete=models.CASCADE)
#     Amount = models.DecimalField(max_digits=10, decimal_places=2)
#     Mode = models.CharField(max_length=20)

#     def __str__(self):
#         return f"Payment {self.PaymentId} for Booking {self.BookingId}"


# class Review(models.Model):
#     ReviewId = models.AutoField(auto_created=True, primary_key=True)
#     UserId = models.ForeignKey(User_tbl, on_delete=models.CASCADE)
#     VehicleId = models.ForeignKey(Vehicle, on_delete=models.CASCADE)
#     Review = models.TextField(max_length=1000)  # Long reviews allowed
#     Rating = models.IntegerField()

#     def __str__(self):
#         return f"Review by {self.UserId} for {self.VehicleId}"
