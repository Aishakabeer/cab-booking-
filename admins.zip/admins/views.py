# from django.shortcuts import render
# from User.models import User_tbl,vehicle,booking,payment
# # Create your views here.
# def index(request):

#     return render(request, 'admin.html')

# def vehicles(request):
#     veh = vehicle.objects.order_by('User_id').all()
#     return render(request, 'admvehicle.html',{"book":veh})

# def user(request):
#     user = User_tbl.objects.filter(role="user").all()
#     context={ "User" }
#     return render(request, 'admuser.html',{"book":user,"user":context})

# def owner(request):
#     user = User_tbl.objects.filter(role="owner").all()
#     context = { "Owners" }
#     return render(request, 'admuser.html',{"book":user,"user":context})

# def bookings(request):
#     veh = booking.objects.all().order_by('VehicleId')

    
#     return render(request, 'admbooking.html',{'book':veh})
from django.shortcuts import render
from User.models import User_tbl, Vehicle, Booking, Payment

# Admin homepage
def index(request):
    return render(request, 'admin.html')

# Vehicle management
def vehicles(request):
    veh = Vehicle.objects.order_by('User_id').all()
    return render(request, 'admvehicle.html', {"book": veh})

# User management
def user(request):
    users = User_tbl.objects.filter(role="user").all()
    return render(request, 'admuser.html', {"book": users, "user": "User"})

# Owner management
def owner(request):
    owners = User_tbl.objects.filter(role="owner").all()
    return render(request, 'admuser.html', {"book": owners, "user": "Owners"})

# Booking management
def bookings(request):
    bookings = Booking.objects.order_by('VehicleId').all()
    return render(request, 'admbooking.html', {'book': bookings})
