from django.db import models
from User.models import User_tbl

class Vehicle(models.Model):
    Vehicleid = models.AutoField(auto_created=True, primary_key=True)
    User_id = models.ForeignKey(User_tbl, on_delete=models.CASCADE, related_name='vehicles')  # Ensure related_name is correct
    reg_no = models.CharField(max_length=20, unique=True)  # Ensure registration number is unique
    type = models.CharField(max_length=20)
    active = models.BooleanField(default=False)
    pickup = models.CharField(max_length=100)
    drop = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.reg_no

    @classmethod
    def get_inactive(cls):
        """Return all inactive vehicles."""
        return cls.objects.filter(active=False)

class Booking(models.Model):
    Bookingid = models.AutoField(primary_key=True)
    VehicleId = models.ForeignKey(Vehicle, on_delete=models.CASCADE, related_name='bookings')  # Related_name for reverse lookup
    user = models.ForeignKey(User_tbl, on_delete=models.CASCADE, related_name='bookings')  # Changed related_name to 'bookings'
    complete = models.BooleanField(default=False)

    def __str__(self):
        return f"Booking {self.Bookingid}"
