# from django.shortcuts import render, redirect, HttpResponse
# from User.models import User_tbl, vehicle, booking, payment
# from django.db.models import Subquery
# from datetime import datetime, time


# # Create your views here.
# def vehlogin(request):
#     if 'phone' in request.session:
#         return redirect('vehicle/')
#     if request.method == "POST":
#         phone = request.POST.get('phone')
#         password = request.POST.get('password')
#         user = User_tbl.objects.filter(phonenumber=phone, password=password, role="owner").last()
#         user1 = User_tbl.objects.filter(phonenumber=phone, password=password, role="admin").last()

#         if user or user1 is not None:
#             if user is not None:
#                 request.session['phone'] = phone
#                 return redirect('vehicle/')
#             else:
#                 request.session['phone'] = phone
#                 return redirect('/Admins/')
#         else:
#             return HttpResponse("signupfirst")
#     return render(request, 'vehlogin.html')


# def vehindex(request):
#     phone = request.session['phone']
#     id = User_tbl.objects.filter(phonenumber=phone).last().Userid
#     veh = vehicle.objects.filter(User_id=id)
#     return render(request, 'vehicle.html', {'veh': veh})


# def vehbooking(request):
#     phone = request.session['phone']
#     id = User_tbl.objects.filter(phonenumber=phone).last().Userid
#     veh = vehicle.objects.filter(User_id=id)
#     if veh is not None:
#         vehicl = veh.values_list('Vehicleid', flat=True)
#         book = booking.objects.filter(VehicleId__in=Subquery(vehicl), complete=1)
#         return render(request, 'vehbooking.html', {'book': book})
#     return render(request, 'vehbooking.html')


# def vehpayment(request):
#     phone = request.session['phone']
#     id = User_tbl.objects.filter(phonenumber=phone).last().Userid
#     veh = vehicle.objects.filter(User_id=id)
#     if veh is not None:
#         vehicl = veh.values_list('Vehicleid', flat=True)
#         booke = booking.objects.filter(VehicleId__in=Subquery(vehicl)).values_list('Bookingid', flat=True)
#         if booke is not None:
#            book = payment.objects.filter(BookingId__in=Subquery(booke))
#            return render(request, 'vehpayment.html', {'veh': book})
#     return render(request, 'vehpayment.html')


# def vehactive(request):
#     phone = request.session['phone']
#     id = User_tbl.objects.filter(phonenumber=phone).last().Userid
#     if request.method == "POST":
#         if request.POST.get('submit') is not None:
#             book = request.POST.get('submit')
#             saverecord = booking.objects.filter(Bookingid=book).last()
#             saverecord.complete = 1
#             saverecord.save()
#         if request.POST.get('submit1') is not None:
#             book = request.POST.get('submit1')
#             saverecords = booking.objects.filter(Bookingid=book).last()
#             saverecords.accept = 1
#             saverecords.save()

#     veh = vehicle.objects.filter(User_id=id)
#     vehicl = veh.values_list('Vehicleid', flat=True)
#     book = booking.objects.filter(VehicleId__in=Subquery(vehicl), complete=1)

#     return render(request, 'vehactive.html', {'veh': book})


# def vehadd(request):
#     phone = request.session['phone']
#     user = User_tbl.objects.filter(phonenumber=phone).last().Userid
#     if request.method == "POST":
#         no = request.POST.get('no')
#         type = request.POST.get('type')
#         pickup = request.POST.get('pickup')
#         drop = request.POST.get('drop')
#         amount = request.POST.get('amount')
#         check = vehicle.objects.filter(reg_no=no).last()
#         check1 = vehicle.objects.filter(User_id=user, reg_no=no).last()
#         if check1 is None:
#             if check is None:
#                 user = User_tbl.objects.get(Userid=user)
#                 saverecords = vehicle()
#                 saverecords.reg_no = no
#                 saverecords.type = type
#                 saverecords.active = 0
#                 saverecords.time = '00:00:00'
#                 saverecords.pickup = pickup
#                 saverecords.drop = drop
#                 saverecords.User_id = user
#                 saverecords.amount = amount
#                 saverecords.save()
#                 return HttpResponse("Vehicle Added")
#             else:
#                 return HttpResponse("Vehicle Alredy Found")
#         else:
#             saverecords = vehicle.objects.filter(User_id=user).last()
#             saverecords.reg_no = no
#             saverecords.type = type
#             saverecords.pickup = pickup
#             saverecords.drop = drop
#             saverecords.amount = amount
#             saverecords.save()
#             return HttpResponse("Vehicle Updated")

#     vehicl = vehicle.objects.filter(User_id=user).last()
#     if vehicl is not None:
#         return render(request, 'addvehicle.html', {"vehicl": vehicl})

#     else:
#         return render(request, 'addvehicle.html')


from django.shortcuts import render, redirect, HttpResponse
from User.models import User_tbl, Booking, Payment

from .models import Vehicle
from django.db.models import Subquery

def vehlogin(request):
    if 'phone' in request.session:
        return redirect('vehindex')
    if request.method == "POST":
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        user = User_tbl.objects.filter(phonenumber=phone, password=password, role="owner").last()
        user1 = User_tbl.objects.filter(phonenumber=phone, password=password, role="admin").last()

        if user or user1:
            request.session['phone'] = phone
            return redirect('vehindex' if user else '/Admins/')
        else:
            return HttpResponse("Please signup first.")
    return render(request, 'vehlogin.html')


def vehindex(request):
    phone = request.session.get('phone')
    user = User_tbl.objects.filter(phonenumber=phone).last()
    if user:
        veh = Vehicle.objects.filter(User_id=user.Userid)
        return render(request, 'vehicle.html', {'veh': veh})
    return redirect('vehlogin')

def vehbooking(request):
    phone = request.session.get('phone')
    user = User_tbl.objects.filter(phonenumber=phone).last()
    if user:
        veh_ids = Vehicle.objects.filter(User_id=user.Userid).values_list('Vehicleid', flat=True)
        bookings = Booking.objects.filter(VehicleId__in=Subquery(veh_ids), complete=True)
        return render(request, 'vehbooking.html', {'bookings': bookings})
    return redirect('vehlogin')


def vehpayment(request):
    phone = request.session.get('phone')
    user = User_tbl.objects.filter(phonenumber=phone).last()
    if user:
        veh_ids = Vehicle.objects.filter(User_id=user.Userid).values_list('Vehicleid', flat=True)
        booking_ids = Booking.objects.filter(VehicleId__in=Subquery(veh_ids)).values_list('Bookingid', flat=True)
        payments = Payment.objects.filter(BookingId__in=Subquery(booking_ids))
        return render(request, 'vehpayment.html', {'payments': payments})
    return redirect('vehlogin')

def vehadd(request):
    phone = request.session.get('phone')
    user = User_tbl.objects.filter(phonenumber=phone).last()
    if user:
        if request.method == "POST":
            reg_no = request.POST.get('no')
            type = request.POST.get('type')
            pickup = request.POST.get('pickup')
            drop = request.POST.get('drop')
            amount = request.POST.get('amount')

            vehicle = Vehicle.objects.filter(reg_no=reg_no, User_id=user.Userid).last()
            if not vehicle:
                vehicle = Vehicle(User_id=user, reg_no=reg_no, type=type, pickup=pickup, drop=drop, amount=amount)
                vehicle.save()
                return HttpResponse("Vehicle Added")
            else:
                vehicle.type = type
                vehicle.pickup = pickup
                vehicle.drop = drop
                vehicle.amount = amount
                vehicle.save()
                return HttpResponse("Vehicle Updated")
        return render(request, 'addvehicle.html')
    return redirect('vehlogin')



def vehactive(request):
    phone = request.session['phone']
    id = User_tbl.objects.filter(phonenumber=phone).last().Userid
    if request.method == "POST":
        if request.POST.get('submit') is not None:
            book = request.POST.get('submit')
            saverecord = Booking.objects.filter(Bookingid=book).last()
            saverecord.complete = 1
            saverecord.save()
        if request.POST.get('submit1') is not None:
            book = request.POST.get('submit1')
            saverecords = Booking.objects.filter(Bookingid=book).last()
            saverecords.accept = 1
            saverecords.save()

    veh = Vehicle.objects.filter(User_id=id)
    vehicl = veh.values_list('Vehicleid', flat=True)
    book = Booking.objects.filter(VehicleId__in=Subquery(vehicl), complete=1)

    return render(request, 'vehactive.html', {'veh': book})

